

-This IS MY PROJECT I created for the 2016 NASA SPACE APPS competition for the challenge #321Liftoff �Launch - A Global experience�

-IT PRESENTS A VIRTUAL REALITY EXPERIENCE  of rocket launches (VR EXPERIENCES CREATED SO FAR BY NASA AND BY ULA , RESPECTIVELY LOCKHEED MARTIN)

AND A MAP WITH DIRECT ACCESS TO VIDEO ARCHIVES OF ROCKET LAUNCHES AROUND THE GLOBE (SOME ALSO WITH VR EXPERIENCES E.G. BAIKONUR)  



-ALSO provides A LAUNCHS COUNTDOWN AROUND THE WORLD (CAPE CANAVERAL, VANDENBERG, BAiKONUR, ....) 
AND WEATHER INFO ON LAUNCH SITE


- The functionalities are presented in a PREZI 

- Resources: HTML5 , Googlemaps API and JAVASCRIPT ,PREZI for presentation

Licenses: MIT License; some web pages used templates provided by  freewebsitetemplates.com for free use 